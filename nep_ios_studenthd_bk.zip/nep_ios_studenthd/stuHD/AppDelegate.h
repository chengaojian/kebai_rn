//
//  AppDelegate.h
//  stuHD
//
//  Created by 三海 on 2017/3/14.
//  Copyright © 2017年 sanhai.nep. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreData/CoreData.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (readonly, strong) NSPersistentContainer *persistentContainer;

- (void)saveContext;


@end

